/**********************************************************************
  Set_atomicU.c:

     Set_atomicU.c is a subroutine 

  Log of Set_atomicU.c:

     May/2015  Released by J.Parq

***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "openmx_common.h"
#include "mpi.h"
#include <omp.h>


double angle_xc(double denR, double r, double dRdr, double *dFdGr, int i, int pi, int ni, double dr, int xc_switch);

double V_XC_GGA(double den0, double dndx, double dndy, double dndz, double F[2]);


void Set_atomicU()
{
  int xcs = XC_switch;
  int numprocs,myid,ID,tag=999;
  int count,NumSpe;
  double aoh,aoxc,norm;
  int i,j,k,l,i1,nI;
  int Lspe,spe,GL,Mul;
  double r,r2,pr,rmin,rmax,h,h2;
  double dRdr;
  double den,fden,bden;
  double coef0,a0,b0;
  double *dFxcdGr;
  double TStime, TEtime;
  /* for MPI */
  MPI_Status stat;
  MPI_Request request;

  dtime(&TStime);

  /* MPI */
  MPI_Comm_size(mpi_comm_level1,&numprocs);
  MPI_Comm_rank(mpi_comm_level1,&myid);

  if (target_l[1] < 0) nI = 1;
  else nI = 2;

  /***********************************************************
                Allocate target_Uh & target_Uxc
  ***********************************************************/

  target_Uh = (double*)malloc(sizeof(double)*nI);
  target_Uxc = (double*)malloc(sizeof(double)*nI);

  /***********************************************************
                Calculation of target_Uh & Uxc
  ***********************************************************/

  if (myid==Host_ID && 0<level_stdout) printf("<Set_atomicU>    target AO Uh & Uxc \n");

  /* allocation */

  dFxcdGr = (double*)malloc(sizeof(double)*(OneD_Grid+1));

  /* calculation */

  spe = WhatSpecies[target_atom];

  rmin = Spe_PAO_RV[spe][0];
  rmax = Spe_Atom_Cut1[spe] + 0.5;
  h = (rmax - rmin)/(double)OneD_Grid;
  h2 = h*2.0;

  for (l=0; l<nI; l++){
    GL = target_l[l];

    if (l==1 && target_l[0]==target_l[1]) Mul = 1;
    else Mul = 0;

    /* Uh: inner integration */
    /* Uxc: integration */

    r = rmin;
    r2 = r*r;
    den = DenRF(spe,GL,Mul,r);
    fden = DenRF(spe,GL,Mul,r+h);
    dRdr = (fden - den)/h;

    a0 = 0.0;
    b0 = 0.5*den*r;
    /* norm = 0.5*den*r2; */

    aoxc = 0.5*angle_xc(den, r, dRdr, dFxcdGr, 0, 0, 1, h, xcs)*den*r2;

    for (i=1; i<OneD_Grid; i++){
      r = rmin + (double)i*h;
      r2 = r*r;
      bden = den;
      den = fden;
      fden = DenRF(spe,GL,Mul,r+h);
      dRdr = (fden - bden)/h2;

      b0 += den*r;
      /* norm += den*r2; */

      aoxc += angle_xc(den, r, dRdr, dFxcdGr, i, i-1, i+1, h2, xcs)*den*r2;
    }

    r = rmax;
    r2 = r*r;
    bden = den;
    den = fden;
    dRdr = (den - bden)/h;

    b0 += 0.5*den*r;
    /* norm += 0.5*den*r2; */

    aoxc += 0.5*angle_xc(den, r, dRdr, dFxcdGr, i, i-1, i, h, xcs)*den*r;

    /* printf(" %lf\n",norm*h); */

    /* Uh: outer integration with reintegration of the inner part */
    /* Uxc: for GGA */

    r = rmin;
    r2 = r*r;
    den = DenRF(spe,GL,Mul,r);

    aoh = 0.5*(a0 + r*b0)*den*r;

    if (xcs == 4) aoxc -= 0.5*angle_xc(den, r, dRdr, dFxcdGr, 0, 0, 1, h, 8)*den*r2;

    for (i=1; i<OneD_Grid; i++){

      pr = r;
      r = rmin + (double)i*h;
      r2 = r*r;
      bden = den;
      den = DenRF(spe,GL,Mul,r);

      a0 += (bden*pr*pr + den*r2)/2.0;
      b0 -= (bden*pr + den*r)/2.0;

      aoh += (a0 + r*b0)*den*r;

      if (xcs == 4) aoxc -= angle_xc(den, r, dRdr, dFxcdGr, i, i-1, i+1, h2, 8)*den*r2;
    }

    pr = r;
    r = rmax;
    r2 = r*r;
    bden = den;
    den = DenRF(spe,GL,Mul,r);

    a0 += (bden*pr*pr + den*r2)*0.5;
    b0 -= (bden*pr + den*r)*0.5;

    aoh += 0.5*(a0 + r*b0)*den*r;

    if (xcs == 4) aoxc -= 0.5*angle_xc(den, r, dRdr, dFxcdGr, i, i-1, i, h, 8)*den*r2;

    target_Uh[l] = aoh*h*h;
    target_Uxc[l] = aoxc*h;
    
  } /* l */

  /* freeing */

  free(dFxcdGr);

  /***********************************************************
                         elapsed time
  ***********************************************************/

  dtime(&TEtime);

  /*
  printf("myid=%2d Elapsed Time (s) = %15.12f\n",myid,TEtime-TStime);
  MPI_Finalize();
  exit(0);
  */
}


double angle_xc(double denR, double r, double dRdr, double *dFdGr, int i, int pi, int ni, double dr, int xc_switch)
{
  double den;
  double yt2,result;
  double dndr;
  double dndz,E[2],F[3];

  /* xc_switch

     2: LSDA-CA
     3: LSDA-PW
     4: GGA-PBE 1st part
     8: GGA-PBE 2nd part

   */

  switch (xc_switch) {

  case 2:
    yt2 = 0.25/PI;
    den = denR*yt2;
    XC_CA_LSDA(den,0.0,E,1);
    result = E[0];
    break;

  case 3:
    yt2 = 0.25/PI;
    den = denR*yt2;
    result = V_XC_PW_LSDA(den);
    break;

  case 4:
    yt2 = 0.25/PI;
    den = denR*yt2;
    dndr = dRdr*yt2;
    dndz = dndr;
    result = V_XC_GGA(den,0.0,0.0,dndz,F);
    dFdGr[i] = F[2];
    break;

  case 8:
    result = (dFdGr[ni] - dFdGr[pi])/dr + 2.0*dFdGr[i]/r;
    break;

  default:
    result = 1.0;
  }

  return result;
}

double V_XC_GGA(double den0, double dndx, double dndy, double dndz, double F[3])
{
  double den_min=1.0e-14; 
  double Exc[2],Vxc;
  double ED[2],GDENS[3][2];
  double DEXDD[2],DECDD[2];
  double DEXDGD[3][2],DECDGD[3][2];

  if (den0<den_min) {
    F[0] = 0.0;
    F[1] = 0.0;
    F[3] = 0.0;
    return 0.0;
  }

  ED[0] = den0;
  ED[1] = 0.0;

  GDENS[0][0] = dndx;
  GDENS[1][0] = dndy;
  GDENS[2][0] = dndz;
  GDENS[0][1] = 0.0;
  GDENS[1][1] = 0.0;
  GDENS[2][1] = 0.0;

  XC_PBE(ED, GDENS, Exc, DEXDD, DECDD, DEXDGD, DECDGD);

  Vxc = DEXDD[0] + DECDD[0];

  F[0] = DEXDGD[0][0] + DECDGD[0][0];
  F[1] = DEXDGD[1][0] + DECDGD[1][0];
  F[2] = DEXDGD[2][0] + DECDGD[2][0];

  return Vxc;
}

double V_XC_PW_LSDA(double den0)
{
  double Vxc;
  double den[2],E_unif[2],V_unif[2];
  double min_den = 1.0e-14;

  if (den0<min_den) return 0.0;

  den[0] = den0;
  den[1] = 0.0;

  XC_PW92C(den,E_unif,V_unif);
  Vxc = V_unif[0];

  XC_EX(1,2.0*den0,den,E_unif,V_unif);
  Vxc += V_unif[0];

  return Vxc;
}


double RefAOUh(double **qp, double sdr)
{
  int xcs = XC_switch;
  double aoh,a0,b0;
  int spe,GL,Mul,i,j;
  double r,r2,pr,rmin,rmax,h,h2;
  double dRdr;
  double den,fden,bden;

  /* calculation */

  spe = WhatSpecies[target_atom];

  rmin = Spe_PAO_RV[spe][0];
  rmax = Spe_Atom_Cut1[spe] + 0.5;
  h = (rmax - rmin)/(double)OneD_Grid;
  h2 = h*2.0;

  /* Uh: inner integration */

  r = rmin;
  r2 = r*r;
  den = 0.0;
  fden = 0.0;
  for (GL=0; GL<=Spe_MaxL_Basis[spe]; GL++) {
    for (Mul=0; Mul<Spe_Num_Basis[spe][GL]; Mul++){
      den += qp[GL][Mul]*DenRF(spe,GL,Mul,r);
      fden += qp[GL][Mul]*DenRF(spe,GL,Mul,r+h);
    }
  }
  den *= sdr;
  fden *= sdr;
  dRdr = (fden - den)/h;

  a0 = 0.0;
  b0 = 0.5*den*r;

  for (i=1; i<OneD_Grid; i++){
    r = rmin + (double)i*h;
    r2 = r*r;
    bden = den;
    den = fden;
    fden = 0.0;
    for (GL=0; GL<=Spe_MaxL_Basis[spe]; GL++) {
      for (Mul=0; Mul<Spe_Num_Basis[spe][GL]; Mul++){
	fden += qp[GL][Mul]*DenRF(spe,GL,Mul,r+h);
      }
    }
    fden *= sdr;
    dRdr = (fden - bden)/h2;

    b0 += den*r;
  }

  r = rmax;
  r2 = r*r;
  bden = den;
  den = fden;
  dRdr = (den - bden)/h;

  b0 += 0.5*den*r;

  /* Uh: outer integration with reintegration of the inner part */

  r = rmin;
  r2 = r*r;
  den =0.0;
  for (GL=0; GL<=Spe_MaxL_Basis[spe]; GL++) {
    for (Mul=0; Mul<Spe_Num_Basis[spe][GL]; Mul++){
      den += qp[GL][Mul]*DenRF(spe,GL,Mul,r);
    }
  }
  den *= sdr;

  aoh = 0.5*(a0 + r*b0)*den*r;

  for (i=1; i<OneD_Grid; i++){
    pr = r;
    r = rmin + (double)i*h;
    r2 = r*r;
    bden = den;
    den = 0.0;
    for (GL=0; GL<=Spe_MaxL_Basis[spe]; GL++) {
      for (Mul=0; Mul<Spe_Num_Basis[spe][GL]; Mul++){
	den += qp[GL][Mul]*DenRF(spe,GL,Mul,r);
      }
    }
    den *= sdr;

    a0 += (bden*pr*pr + den*r2)/2.0;
    b0 -= (bden*pr + den*r)/2.0;
    aoh += (a0 + r*b0)*den*r;

  }

  pr = r;
  r = rmax;
  r2 = r*r;
  bden = den;
  den = 0.0;
  for (GL=0; GL<=Spe_MaxL_Basis[spe]; GL++) {
    for (Mul=0; Mul<Spe_Num_Basis[spe][GL]; Mul++){
      den += qp[GL][Mul]*DenRF(spe,GL,Mul,r);
    }
  }
  den *= sdr;

  a0 += (bden*pr*pr + den*r2)*0.5;
  b0 -= (bden*pr + den*r)*0.5;

  aoh += 0.5*(a0 + r*b0)*den*r;

  aoh *= h*h;
  return aoh;
}


double RefAOUxc(double **qp, double sdr)
{
  int xcs = XC_switch;
  double aoxc;
  int spe,GL,Mul,i,j;
  double r,r2,pr,rmin,rmax,h,h2;
  double dRdr;
  double den,fden,bden;
  double *dFxcdGr;

  if (xcs==4) xcs = 3;

  /* allocation */

  dFxcdGr = (double*)malloc(sizeof(double)*(OneD_Grid+1));

  /* calculation */

  spe = WhatSpecies[target_atom];

  rmin = Spe_PAO_RV[spe][0];
  rmax = Spe_Atom_Cut1[spe] + 0.5;
  h = (rmax - rmin)/(double)OneD_Grid;
  h2 = h*2.0;

  /* Uxc: integration */

  r = rmin;
  r2 = r*r;
  den = 0.0;
  fden = 0.0;
  for (GL=0; GL<=Spe_MaxL_Basis[spe]; GL++) {
    for (Mul=0; Mul<Spe_Num_Basis[spe][GL]; Mul++){
      den += qp[GL][Mul]*DenRF(spe,GL,Mul,r);
      fden += qp[GL][Mul]*DenRF(spe,GL,Mul,r+h);
    }
  }
  den *= sdr;
  fden *= sdr;

  aoxc = 0.5*angle_xc(den, r, dRdr, dFxcdGr, 0, 0, 1, h, xcs)*den*r2;

  for (i=1; i<OneD_Grid; i++){
    r = rmin + (double)i*h;
    r2 = r*r;
    den = fden;
    fden = 0.0;
    for (GL=0; GL<=Spe_MaxL_Basis[spe]; GL++) {
      for (Mul=0; Mul<Spe_Num_Basis[spe][GL]; Mul++){
	fden += qp[GL][Mul]*DenRF(spe,GL,Mul,r+h);
      }
    }
    fden *= sdr;

    aoxc += angle_xc(den, r, dRdr, dFxcdGr, i, i-1, i+1, h2, xcs)*den*r2;
  }

  r = rmax;
  r2 = r*r;
  bden = den;
  den = fden;

  aoxc += 0.5*angle_xc(den, r, dRdr, dFxcdGr, i, i-1, i, h, xcs)*den*r2;

  aoxc *= h;

  /* freeing */

  free(dFxcdGr);

  return aoxc;

}

